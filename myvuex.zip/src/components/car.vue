<template>
  <div class="car">
    <ul>
      <li v-for="(item, index) in list" :key="index">
        <img :src="item.url" />
        <div>
          <div class="line">
            <span>单价:{{ item.price }}</span>
            <span>数量:{{ item.num }}</span>
          </div>
          <div class="btn">
            <button @click="numaddone(item)">+</button>
            <button @click="numnmenuone(item)">-</button>
          </div>
        </div>
      </li>
    </ul>
   
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: []
    };
  },
  created() {
    this.list = this.$store.state.carlist;
  },
  methods: {
    numaddone(item) {
     this.$store.commit('ADDNUM',item)
    },
    numnmenuone(item) {
        this.$store.commit('MENUNUM',item)
    },
  },
//   watch: {
//       'this.$store.state.carlist':function(){
//           window.console.log("----------",this.$store.state.carlist);
          
//           this.list = this.$store.state.carlist;
//       }
//   }

};
</script>

<style lang="less" scoped>
.car {
  position: relative;
  ul {
    list-style: none;

    li {
      display: flex;
      position: relative;
      padding: 10px;
      box-sizing: border-box;
      border-bottom: 1px solid #ccc;
      img {
        width: 50px;
        height: 50px;
        margin-right: 10px;
        display: block;
        //   background-color: pink;
      }
      .line {
        span {
          margin-right: 20px;
        }
      }
      .btn {
        position: absolute;
        bottom: 10px;
        right: 0;
        button {
          width: 20px;
          height: 20px;
          margin-right: 20px;
        }
      }
    }
  }

}
</style>
