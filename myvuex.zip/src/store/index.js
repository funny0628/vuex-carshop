import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex);
const list = localStorage.getItem('LIST') || [];
const store = new Vuex.Store({
    state: {
        //购物车的数据
        carlist: list,
        listnum: 0,


    },
    //作为store的计算属性 , 接受第一个参数为state
    getters: {
        
        getnum: state => {
            return state.carlist.reduce((start, current) => { return start + current.num }, 0)
        },
      
    },
    mutations: {
        //添加购物车的
        ADDCAR(state, payload) {
            let oldlist = JSON.parse(JSON.stringify(state.carlist))
            let tetanus = oldlist.find(it => it.id === payload.id);
            if (tetanus) {
                Vue.prototype.$message({
                    message:'该商品已存在',
                    type:"warning"
                });
            } else {
                payload.num = 1
                oldlist.push(payload);
                Vue.prototype.$message({
                    message:'添加购物车成功',
                    type:"warning"
                });
            }
            return state.carlist = oldlist
        },
        //add num
        ADDNUM(state,payload){
            let oldlist = JSON.parse(JSON.stringify(state.carlist))
            let str = oldlist.find(item => item.id === payload.id);
            if(str){
                str.num ++ 
            }
            window.console.log(state.carlist)
            return state.carlist = oldlist;
        },
        //menu num
        MENUNUM(state,payload){
            let oldlist = JSON.parse(JSON.stringify(state.carlist))
            let str = oldlist.find(item => item.id === payload.id);
            if(str){
                str.num -- 
            }
            window.console.log(state.carlist)
            return state.carlist = oldlist;
        }
    },
    actions: {

    }
})
export default store;